"""
planner.py  —  Figma design planner

Takes a user prompt and returns a structured JSON plan describing
the full website layout: pages, sections, components, and image placeholders.
Used by the /generate endpoint to drive Figma frame generation.

This is SEPARATE from planner_react.py which handles React code export.
"""

import os
import json
import re
import asyncio
from google import genai
from dotenv import load_dotenv
from llm_utils import generate_content_with_retry
import logger as log

load_dotenv()

planner_model = os.getenv("GEMINI_PLANNER_MODEL")
client = genai.Client(api_key=os.getenv("GEMINI_API_KEY1"))

STATE_EXTRACTOR_PROMPT = """
You are a UI/UX analyst. You receive a content context from a requirements document.

Extract EVERY distinct UI state that needs its own Figma frame, but organize them as feature flows.
Each flow is a left-to-right user journey.
One frame per meaningful UI moment: default view, modal open, after action, error state, popup, panel, expanded card, secondary state.
Cover every interaction: clicks, panels, drawers, menus, modals, transitions, result states.
Do NOT merge meaningful states together.
Do NOT omit workflows.
Only add annotations for important explanatory states, not every frame.
Think about the product as one connected system:
- infer the shared app/site shell before splitting into states
- keep related screens under one stable information architecture
- if multiple states belong to the same area, keep the same top-level navigation destination and shell

Output ONLY a JSON array:
[
  {
    "id": "state_1",
    "name": "Feature Name — Screen Name",
    "screen_title": "Screen Name",
    "feature_group": "Dashboard",
    "flow_step": 1,
    "flow_total": 3,
    "ui_state": "default",
    "description": "Main dashboard showing call list with incoming, ongoing, missed statuses",
    "components": ["sidebar nav", "topbar", "call list", "status badges", "action buttons"],
    "click_target_keywords": ["button name or component that triggers the next state"],
    "annotation_text": "Optional annotation for an important screen",
    "annotation_target_keywords": ["keyword for the component that the annotation should point to"],
    "height": 1080
  }
]

CONTENT CONTEXT:
{content_context}

Output ONLY the JSON array. No explanation.
"""


FREE_PLANNER_PROMPT = """
You are a senior UI/UX architect for an AI-powered Figma generator.

Generate complete feature flows, not isolated screens.
Each feature flow should be a left-to-right user journey made of multiple screen states.
Every screen must represent one meaningful UI moment in that journey.
You may be given a simple prompt only, so you must infer the likely workflows and interaction states without hardcoding to any specific product domain.

CRITICAL RULES:
1. Output ONLY valid JSON. No markdown, no explanations.
2. Frame width ALWAYS 1440px.
3. Height: 900-1080px for app screens, 1800-3200px for landing pages.
4. For every major action or interaction, add a separate frame showing the resulting state.
5. Group related screens under the same `feature_group`.
6. Use sequential screen names that make the flow obvious.
7. Start each feature with the most natural default screen, then show the triggered states after it.
8. Capture all important flows, menus, drawers, modals, expanded cards, secondary tabs, success/error states, and inline interaction states.
9. Add annotations only for key explanatory moments, not every single frame.
10. If the input references a screenshot or existing product screen, ignore any empty capture padding around the UI and plan the actual site/app surface as a full-size design.
11. Include these metadata fields for each page:
   - `screen_title`
   - `flow_step`
   - `flow_total`
   - `click_target_keywords`
     - `annotation_text`
     - `annotation_target_keywords`
12. Infer a stable shared information architecture for the project so related screens reuse the same top-level destinations and shell.
13. For website or product-site requests, structure the plan as action branches from the main home page:
    - Home -> click Demo / Request Demo -> demo flow
    - Home -> click Login / Sign In -> auth flow
    - Home -> click Category / Shop -> browsing flow
    - Home -> click Product -> product-detail flow
    - Home -> click Product -> Add to Cart -> Cart -> Checkout steps -> Confirmation
14. For those website-style flows, repeat the home page as the first step of each branch rather than mixing everything into one giant row.

OUTPUT FORMAT:
{
  "project_title": "string",
  "website_goal": "string",
  "total_pages": number,
  "pages": [
    {
      "id": "page1",
      "name": "Dashboard — Default",
      "screen_title": "Dashboard",
      "feature_group": "Dashboard",
      "flow_step": 1,
      "flow_total": 1,
      "description": "Main dashboard showing call list",
      "click_target_keywords": ["button name"],
      "annotation_text": "Optional explanatory callout for the key component in this screen",
      "annotation_target_keywords": ["component keyword"],
      "width": 1440,
      "height": 1080,
      "sections": [
        {
          "section_name": "Call List",
          "purpose": "Show active and recent calls",
          "components": ["sidebar", "topbar", "call items", "status badges"]
        }
      ],
      "images": []
    }
  ]
}

USER REQUEST:
{user_prompt}
"""

FLOW_SYNTHESIS_PROMPT = """
You are a senior product UX architect.

You will receive:
1. CONTENT CONTEXT extracted from the source material
2. RAW UI STATES extracted from that material

Your job is to transform the raw states into clean, generic feature flows.

You must THINK structurally, not literally.

RULES:
- Do NOT simply preserve the source order if it starts mid-flow.
- Identify the natural parent screen or baseline state for each feature.
- Reorder each feature into a clean left-to-right journey:
  baseline/default screen -> action state -> resulting state -> modal/panel/transition -> completion/error if relevant
- Dedupe repeated or near-duplicate states.
- Keep branches as separate subflows when needed, but keep them understandable.
- Do NOT hardcode a particular domain; reason from the supplied context.
- Only include important annotations, not one on every frame.
- Keep every meaningful interaction, but present it as a coherent product flow.
- Infer the shared information architecture of the product and keep it consistent across the feature flows.
- Prefer stable primary destinations and shared shell patterns over screen-by-screen reinvention.
- For website-style products, convert the plan into action branches from the home page instead of one long sequential sitemap.
- Example branch style:
  Home -> Demo
  Home -> Login
  Home -> Browse Category
  Home -> Product Detail
  Home -> Product Detail -> Add to Cart -> Checkout

Return ONLY a JSON array in this exact shape:
[
  {
    "id": "state_1",
    "name": "Feature Name — Screen Name",
    "screen_title": "Screen Name",
    "feature_group": "Feature Name",
    "flow_step": 1,
    "flow_total": 3,
    "ui_state": "default",
    "description": "What this screen shows and why it exists in the flow",
    "components": ["sidebar", "table", "detail panel"],
    "click_target_keywords": ["button or trigger for the next state"],
    "annotation_text": "",
    "annotation_target_keywords": [],
    "height": 1080
  }
]

CONTENT CONTEXT:
{content_context}

RAW UI STATES:
{ui_states}
"""

DEFAULT_KEYWORDS = [
    "default", "base", "home", "overview", "dashboard", "main", "list", "index",
    "landing", "shell", "workspace", "board", "table", "inbox"
]
SECONDARY_KEYWORDS = [
    "popup", "modal", "drawer", "dialog", "panel", "card", "detail", "selected",
    "open", "expanded", "active", "playing", "ringing", "incoming", "confirm",
    "confirmation", "delete", "edit", "form", "search", "results", "transfer",
    "hold", "resume", "error", "success", "loading", "progress"
]
FEATURE_STOPWORDS = {
    "flow", "interaction", "management", "experience", "state", "screen", "ui",
    "view", "journey", "scenario", "workspace", "module",
}
NAV_GENERIC_LABELS = {"general", "default", "state", "screen", "page", "app", "site"}
NAV_LABEL_PATTERNS = [
    (("home", "landing", "storefront"), "Home"),
    (("dashboard", "workspace"), "Dashboard"),
    (("inbox",), "Inbox"),
    (("category", "catalog", "browse", "browsing", "collection", "shop"), "Shop"),
    (("product detail", "quick view", "detail page", "detail view", "pdp"), "Product"),
    (("cart", "bag", "basket", "mini cart"), "Cart"),
    (("checkout", "shipping", "payment", "confirmation", "order confirmation"), "Checkout"),
    (("search", "results"), "Search"),
    (("profile", "account"), "Account"),
    (("settings", "preferences"), "Settings"),
    (("support", "help"), "Support"),
]
FLOW_RESET_THRESHOLD = 18
NAV_PREFERRED_ORDER = [
    "Home", "Shop", "Products", "Categories", "Pricing", "Demo", "Request Demo",
    "Get Started", "Login", "Sign In", "Account", "Cart", "Checkout", "Dashboard",
    "Agent", "Admin Routing", "Support", "Settings",
]


def _norm_text(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (value or "").lower()).strip()


def _pretty_title(value: str) -> str:
    text = re.sub(r"\s+", " ", (value or "").strip(" -–—:"))
    if not text:
        return "State"
    return " ".join(word[:1].upper() + word[1:] if word else "" for word in text.split(" "))


def _clean_feature_label(value: str) -> str:
    title = _pretty_title(value)
    words = [w for w in title.split() if _norm_text(w) not in FEATURE_STOPWORDS]
    cleaned = " ".join(words).strip()
    return cleaned or title or "Feature"


def _split_feature_and_screen(state: dict, fallback_idx: int) -> tuple[str, str]:
    feature = state.get("feature_group") or ""
    screen = state.get("screen_title") or ""
    name = state.get("name") or ""

    if "—" in name:
        parts = [p.strip() for p in name.split("—", 1)]
        if not feature and parts[0]:
            feature = parts[0]
        if not screen and len(parts) > 1 and parts[1]:
            screen = parts[1]
    elif " - " in name:
        parts = [p.strip() for p in name.split(" - ", 1)]
        if not feature and parts[0]:
            feature = parts[0]
        if not screen and len(parts) > 1 and parts[1]:
            screen = parts[1]

    if not feature:
        feature = screen or name or f"Feature {fallback_idx}"
    if not screen:
        screen = name or f"State {fallback_idx}"

    return _clean_feature_label(feature), _pretty_title(screen)


def _infer_nav_label(page: dict) -> str:
    screen = page.get("screen_title", "") or ""
    feature = page.get("feature_group", "") or ""
    description = page.get("description", "") or ""
    combined = " ".join([screen, feature, description]).lower()

    if "category" in screen.lower():
        prefix = re.split(r"category", screen, flags=re.IGNORECASE)[0].strip(" -–—:")
        if prefix and _norm_text(prefix) not in NAV_GENERIC_LABELS:
            return _pretty_title(prefix)

    for patterns, label in NAV_LABEL_PATTERNS:
        if any(p in combined for p in patterns):
            return label

    feature_label = _clean_feature_label(feature)
    if _norm_text(feature_label) not in NAV_GENERIC_LABELS:
        return feature_label

    screen_label = _pretty_title(screen)
    if _norm_text(screen_label) not in NAV_GENERIC_LABELS:
        return screen_label

    return "Home"


def _page_kind(page: dict) -> str:
    hay = _norm_text(" ".join([
        page.get("name", ""),
        page.get("screen_title", ""),
        page.get("feature_group", ""),
        page.get("description", ""),
        " ".join(page.get("components", []) or []),
    ]))

    if any(k in hay for k in ["login", "sign in", "signin", "auth", "register", "create account"]):
        return "auth"
    if any(k in hay for k in ["request demo", "demo", "get started", "book demo", "contact sales"]):
        return "demo"
    if any(k in hay for k in ["checkout", "shipping", "payment", "billing", "place order", "review order"]):
        return "checkout"
    if any(k in hay for k in ["order confirmation", "thank you", "receipt", "confirmation"]):
        return "confirmation"
    if any(k in hay for k in ["cart", "bag", "basket", "mini cart"]):
        return "cart"
    if any(k in hay for k in ["product detail", "quick view", "detail page", "detail view", "pdp", "product page"]):
        return "product"
    if any(k in hay for k in ["category", "catalog", "browse", "browsing", "collection", "shop", "results"]):
        return "browse"
    if any(k in hay for k in ["home", "landing", "storefront", "default", "overview", "dashboard", "inbox", "main"]):
        return "base"
    return "feature"


def _sort_nav_links(labels: list[str]) -> list[str]:
    seen = set()
    ordered = []
    for preferred in NAV_PREFERRED_ORDER:
        for label in labels:
            if label == preferred and label not in seen:
                ordered.append(label)
                seen.add(label)
    for label in labels:
        if label not in seen:
            ordered.append(label)
            seen.add(label)
    return ordered


def _is_website_style(pages: list[dict]) -> bool:
    kinds = {_page_kind(page) for page in pages}
    return bool(kinds & {"auth", "demo", "browse", "product", "cart", "checkout", "confirmation"}) or any(
        _infer_nav_label(page) in {"Home", "Shop", "Product", "Cart", "Checkout"}
        for page in pages
    )


def _infer_nav_layout(pages: list[dict]) -> str:
    if _is_website_style(pages):
        return "topbar"

    sidebar_hits = 0
    topbar_hits = 0

    for page in pages:
        haystacks = [
            page.get("name", ""),
            page.get("screen_title", ""),
            page.get("description", ""),
            " ".join(page.get("components", []) or []),
        ]
        for section in page.get("sections", []) or []:
            haystacks.extend([
                section.get("section_name", ""),
                section.get("purpose", ""),
                " ".join(section.get("components", []) or []),
            ])
        hay = _norm_text(" ".join(haystacks))
        if any(k in hay for k in ["sidebar", "side nav", "left rail"]):
            sidebar_hits += 1
        if any(k in hay for k in ["navbar", "navigation", "topbar", "header", "menu"]):
            topbar_hits += 1

    if sidebar_hits >= max(2, topbar_hits + 1):
        return "sidebar"
    if topbar_hits > 0 and sidebar_hits > 0:
        return "hybrid"
    return "topbar"


def _clone_page_for_flow(page: dict, suffix: str) -> dict:
    clone = dict(page)
    clone["id"] = f"{page.get('id', 'page')}_{suffix}"
    return clone


def _branch_label_for_feature(feature_name: str, feature_pages: list[dict], fallback_home: str) -> str:
    for page in feature_pages:
        if _page_kind(page) != "base":
            label = _clean_feature_label(page.get("screen_title", "") or page.get("name", ""))
            if label and _norm_text(label) not in NAV_GENERIC_LABELS:
                return f"{fallback_home} -> {label}"
    feature_label = _clean_feature_label(feature_name)
    return f"{fallback_home} -> {feature_label or 'Feature'}"


def _website_branch_order(page: dict) -> tuple[int, int, str]:
    kind = _page_kind(page)
    text = _norm_text(" ".join([
        page.get("name", ""),
        page.get("screen_title", ""),
        page.get("description", ""),
    ]))

    if kind == "base":
        rank = 0
    elif kind == "auth":
        rank = 10
    elif kind == "demo":
        rank = 12
    elif kind == "browse":
        rank = 20
    elif kind == "product":
        rank = 30
    elif kind == "cart":
        rank = 40
    elif kind == "checkout":
        rank = 50
    elif kind == "confirmation":
        rank = 70
    else:
        rank = 24

    if "home page" in text or "landing page" in text:
        rank = min(rank, 5 if kind != "base" else 0)
    if any(k in text for k in ["about", "story", "our story"]):
        rank = min(rank, 22)
    if any(k in text for k in ["sustainability", "mission", "values"]):
        rank = min(rank, 26)
    if any(k in text for k in ["events", "tours"]):
        rank = min(rank, 28)
    if any(k in text for k in ["select date", "select time", "schedule", "booking form", "registration"]):
        rank = min(rank, 36)
    if any(k in text for k in ["shipping", "address"]):
        rank = 52
    if any(k in text for k in ["billing", "payment", "upi", "card"]):
        rank = 58
    if any(k in text for k in ["confirmed", "confirmation", "thank you", "receipt"]):
        rank = 72

    return rank, _state_rank(page)[1], page.get("name", "")


def _attach_project_structure(pages: list[dict]) -> tuple[list[dict], dict]:
    if not pages:
        return [], {"layout": "topbar", "primary_links": []}

    primary_links = []
    seen_links = set()
    feature_active = {}

    for page in pages:
        label = _infer_nav_label(page)
        feature_key = _norm_text(page.get("feature_group", "") or page.get("screen_title", ""))
        if feature_key and feature_key not in feature_active:
            feature_active[feature_key] = label
        if label and label not in seen_links:
            primary_links.append(label)
            seen_links.add(label)

    primary_links = _sort_nav_links(primary_links)
    if len(primary_links) > 8:
        primary_links = primary_links[:8]

    layout = _infer_nav_layout(pages)
    anchor_candidates = sorted(pages, key=_state_rank)
    anchor_page = anchor_candidates[0] if anchor_candidates else pages[0]

    by_feature: dict[str, list[dict]] = {}
    for page in pages:
        key = page.get("feature_group", "") or page.get("name", "")
        by_feature.setdefault(key, []).append(page)

    page_groups = {
        "auth": [],
        "demo": [],
        "browse": [],
        "product": [],
        "cart": [],
        "checkout": [],
        "confirmation": [],
        "feature": [],
    }
    anchor_feature_key = anchor_page.get("feature_group", "") or anchor_page.get("name", "")
    for feature_name, feature_pages in by_feature.items():
        ordered_feature_pages = sorted(feature_pages, key=_website_branch_order)
        if feature_name == anchor_feature_key:
            continue
        kind = _page_kind(ordered_feature_pages[0])
        if kind in page_groups:
            page_groups[kind].append((feature_name, ordered_feature_pages))
        else:
            page_groups["feature"].append((feature_name, ordered_feature_pages))

    flow_groups = []

    def push_flow(name: str, branch_pages: list[dict], include_anchor: bool = True):
        if not branch_pages:
            return
        slug = _norm_text(name).replace(" ", "_") or "root"
        pages_for_flow = []
        if include_anchor:
            pages_for_flow.append(_clone_page_for_flow(anchor_page, f"{slug}_start"))
        for idx, page in enumerate(branch_pages, start=1):
            pages_for_flow.append(_clone_page_for_flow(page, f"{slug}_{idx}"))
        flow_groups.append({
            "name": name,
            "pages": pages_for_flow,
        })

    home_label = _clean_feature_label(anchor_page.get("screen_title", "Home")) or "Home"

    for feature_name, feature_pages in page_groups["demo"]:
        push_flow(_branch_label_for_feature(feature_name, feature_pages, home_label), feature_pages)

    for feature_name, feature_pages in page_groups["auth"]:
        push_flow(_branch_label_for_feature(feature_name, feature_pages, home_label), feature_pages)

    browse_seeds = []
    for feature_name, feature_pages in page_groups["browse"]:
        push_flow(_branch_label_for_feature(feature_name, feature_pages, home_label), feature_pages)
        browse_seeds.extend(feature_pages[:1])

    for feature_name, feature_pages in page_groups["feature"]:
        push_flow(_branch_label_for_feature(feature_name, feature_pages, home_label), feature_pages)

    product_pages = [page for _, pages_list in page_groups["product"] for page in pages_list]
    cart_pages = [page for _, pages_list in page_groups["cart"] for page in pages_list]
    checkout_pages = [page for _, pages_list in page_groups["checkout"] for page in pages_list]
    confirmation_pages = [page for _, pages_list in page_groups["confirmation"] for page in pages_list]

    if product_pages:
        product_branch = []
        if browse_seeds:
            product_branch.extend([browse_seeds[0]])
        product_branch.extend(sorted(product_pages, key=_website_branch_order))
        push_flow(f"{home_label} -> Product Detail", product_branch)

    if cart_pages or checkout_pages or confirmation_pages:
        purchase_branch = []
        if product_pages:
            purchase_branch.append(sorted(product_pages, key=_website_branch_order)[0])
        purchase_branch.extend(sorted(cart_pages, key=_website_branch_order))
        purchase_branch.extend(sorted(checkout_pages, key=_website_branch_order))
        purchase_branch.extend(sorted(confirmation_pages, key=_website_branch_order))
        push_flow(f"{home_label} -> Checkout", purchase_branch)

    if not flow_groups:
        feature_order = []
        for feature_name in by_feature:
            if feature_name != anchor_feature_key:
                feature_order.append(feature_name)
        current_flow = None
        for feature_name in feature_order:
            feature_pages = sorted(by_feature[feature_name], key=_website_branch_order)
            first_rank = _state_rank(feature_pages[0])[0] if feature_pages else 50
            starts_new_flow = current_flow is None or first_rank <= FLOW_RESET_THRESHOLD
            if starts_new_flow:
                current_flow = {
                    "name": _branch_label_for_feature(feature_name, feature_pages, home_label),
                    "pages": [_clone_page_for_flow(anchor_page, _norm_text(feature_name).replace(" ", "_") or "root")] + list(feature_pages),
                }
                flow_groups.append(current_flow)
            else:
                current_flow["pages"].extend(feature_pages)

    def _flow_group_name(features: list[str]) -> str:
        cleaned = []
        for feature in features:
            label = _clean_feature_label(feature)
            if label and label not in cleaned:
                cleaned.append(label)
        if not cleaned:
            return "Main Flow"
        if len(cleaned) == 1:
            return cleaned[0] + " Flow"
        return cleaned[0] + " To " + cleaned[-1]

    enriched = []
    for flow_index, flow in enumerate(flow_groups, start=1):
        flow_name = flow.get("name") or _flow_group_name(flow.get("features", []))
        flow_id = f"flow_{flow_index}_{_norm_text(flow_name).replace(' ', '_') or flow_index}"
        flow_pages = flow["pages"]
        flow_total = len(flow_pages)
        for idx, page in enumerate(flow_pages):
            prev_page = flow_pages[idx - 1] if idx > 0 else None
            next_page = flow_pages[idx + 1] if idx + 1 < len(flow_pages) else None
            active_label = _infer_nav_label(page)
            navigation = {
                "layout": layout,
                "primary_links": primary_links,
                "active_label": active_label,
            }
            journey = {
                "previous_screen": prev_page.get("screen_title", "") if prev_page else "",
                "next_screen": next_page.get("screen_title", "") if next_page else "",
                "previous_page_name": prev_page.get("name", "") if prev_page else "",
                "next_page_name": next_page.get("name", "") if next_page else "",
            }
            annotation_text = page.get("annotation_text", "")
            annotation_target_keywords = page.get("annotation_target_keywords", [])
            if not annotation_text and next_page and page.get("click_target_keywords"):
                click_label = ", ".join(page.get("click_target_keywords", [])[:2]).strip()
                next_label = next_page.get("screen_title", "") or next_page.get("name", "")
                if click_label and next_label:
                    annotation_text = f"Click {click_label} to open {next_label}."
                    annotation_target_keywords = page.get("click_target_keywords", [])
            enriched.append({
                **page,
                "name": f"{flow_name} — {page.get('screen_title', page.get('name', 'Screen'))}",
                "flow_group_id": flow_id,
                "flow_group": flow_name,
                "flow_group_step": idx + 1,
                "flow_group_total": flow_total,
                "annotation_text": annotation_text,
                "annotation_target_keywords": annotation_target_keywords,
                "navigation": navigation,
                "journey": journey,
                "project_navigation": {
                    "layout": layout,
                    "primary_links": primary_links,
                },
            })

    return enriched, {
        "layout": layout,
        "primary_links": primary_links,
    }


def _state_rank(state: dict) -> tuple[int, int]:
    text = " ".join([
        state.get("screen_title", ""),
        state.get("name", ""),
        state.get("ui_state", ""),
        state.get("description", ""),
    ])
    norm = _norm_text(text)

    score = 50
    if any(k in norm for k in DEFAULT_KEYWORDS):
        score = 0
    elif any(k in norm for k in ["category", "catalog", "browse", "browsing", "results", "collection", "shop"]):
        score = 12
    elif any(k in norm for k in ["quick view", "product detail", "detail page", "detail view", "pdp"]):
        score = 18
    elif "call detail panel" in norm or "detail panel" in norm or "detail card" in norm:
        score = 18
    elif any(k in norm for k in ["cart", "mini cart", "bag", "basket"]):
        score = 32
    elif any(k in norm for k in ["panel", "card", "selected", "detail", "active"]):
        score = 24
    elif any(k in norm for k in ["menu", "options", "dropdown", "popover"]):
        score = 30
    elif any(k in norm for k in ["shipping", "address"]):
        score = 44
    elif any(k in norm for k in ["payment", "billing"]):
        score = 48
    elif any(k in norm for k in ["review", "place order"]):
        score = 56
    elif any(k in norm for k in ["order confirmation", "thank you", "receipt"]):
        score = 68
    elif any(k in norm for k in ["modal", "dialog", "popup", "confirm", "confirmation"]):
        score = 40
    elif any(k in norm for k in ["success", "saved", "deleted", "completed", "ended", "logged"]):
        score = 60

    # Prefer simpler/core states when rank ties
    tie = len(norm.split())
    return score, tie


def _global_baseline_screen(states: list[dict]) -> dict | None:
    candidates = []
    for idx, state in enumerate(states):
        feature, screen = _split_feature_and_screen(state, idx + 1)
        enriched = {**state, "feature_group": feature, "screen_title": screen}
        rank = _state_rank(enriched)
        if rank[0] <= 18:
            candidates.append((rank, enriched))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def _dedupe_states(states: list[dict]) -> list[dict]:
    seen = set()
    result = []
    for idx, state in enumerate(states, start=1):
        feature, screen = _split_feature_and_screen(state, idx)
        key = (
            _norm_text(feature),
            _norm_text(screen),
            _norm_text(state.get("ui_state", "")),
            _norm_text(state.get("description", ""))[:120],
        )
        if key in seen:
            continue
        seen.add(key)
        result.append({
            **state,
            "feature_group": feature,
            "screen_title": screen,
            "name": f"{feature} — {screen}",
        })
    return result


def _synthesize_baseline_state(feature_group: str, first_state: dict, global_base: dict | None, idx: int) -> dict:
    base_title = (global_base or {}).get("screen_title") or "Default State"
    base_desc = (global_base or {}).get("description") or ""
    description = (
        f"Baseline screen for the {feature_group} flow before the user triggers the next interaction."
    )
    if base_desc:
        description += " " + base_desc

    return {
        "id": f"synth_{idx}",
        "name": f"{feature_group} — {base_title}",
        "screen_title": base_title,
        "feature_group": feature_group,
        "ui_state": "default",
        "description": description,
        "components": first_state.get("components", []),
        "click_target_keywords": first_state.get("click_target_keywords", []),
        "annotation_text": "",
        "annotation_target_keywords": [],
        "width": first_state.get("width", 1440),
        "height": first_state.get("height", 1080),
    }


def _cleanup_flow_states(ui_states: list[dict]) -> list[dict]:
    cleaned = _dedupe_states(ui_states)
    if not cleaned:
        return []

    global_base = _global_baseline_screen(cleaned)

    grouped: dict[str, list[dict]] = {}
    for state in cleaned:
        grouped.setdefault(state["feature_group"], []).append(state)

    ordered = []
    synth_idx = 1
    for feature_group, states in grouped.items():
        states = sorted(states, key=_state_rank)
        if states:
            first_rank = _state_rank(states[0])[0]
            if first_rank > 18:
                states.insert(0, _synthesize_baseline_state(feature_group, states[0], global_base, synth_idx))
                synth_idx += 1

        total = len(states)
        for step, state in enumerate(states, start=1):
            ordered.append({
                **state,
                "flow_step": step,
                "flow_total": total,
                "annotation_target_keywords": state.get("annotation_target_keywords", []),
                "click_target_keywords": state.get("click_target_keywords", []),
            })
    return ordered


def _normalise_pages(pages: list[dict]) -> list[dict]:
    normalised = []
    total = len(pages)
    for i, page in enumerate(pages, start=1):
        p = dict(page)
        p.setdefault("id", f"frame{i}")
        p.setdefault("name", f"Frame {i}")
        p.setdefault("screen_title", p.get("name", f"Frame {i}"))
        p.setdefault("feature_group", p.get("name", f"Frame {i}").split("—")[0].strip())
        p.setdefault("flow_step", i)
        p.setdefault("flow_total", total)
        p.setdefault("click_target_keywords", [])
        p.setdefault("annotation_text", "")
        p.setdefault("annotation_target_keywords", [])
        p.setdefault("width", 1440)
        p.setdefault("height", 1080)
        p.setdefault("images", [])
        p.setdefault("sections", [])
        p.setdefault("flow_group_id", p.get("flow_group", p.get("feature_group", "main_flow")))
        p.setdefault("flow_group", p.get("feature_group", "Main Flow"))
        p.setdefault("flow_group_step", p.get("flow_step", i))
        p.setdefault("flow_group_total", p.get("flow_total", total))
        p.setdefault("navigation", {})
        p.setdefault("journey", {})
        p.setdefault("project_navigation", {})
        normalised.append(p)
    return normalised


async def _run_flow_synthesis(ui_states: list[dict], content_context: dict) -> list[dict]:
    content_str = json.dumps(content_context or {}, indent=2)
    state_str = json.dumps(ui_states, indent=2)
    prompt = FLOW_SYNTHESIS_PROMPT.replace("{content_context}", content_str[:8000]).replace("{ui_states}", state_str[:12000])

    response = await generate_content_with_retry(
        client=client,
        model=planner_model,
        contents=prompt,
        config={"temperature": 0.2},
        log_tag="PLANNER",
        action="Run flow synthesis",
    )
    return _parse_state_list(response.text)


def _call_flow_page(
    idx: int,
    feature_group: str,
    screen_title: str,
    description: str,
    flow_step: int,
    flow_total: int,
    click_target_keywords: list | None = None,
    annotation_text: str | None = None,
    annotation_target_keywords: list | None = None,
    ui_state: str = "default",
    components: list | None = None,
) -> dict:
    return {
        "id": f"flow_{idx}",
        "name": f"{feature_group} — {screen_title}",
        "screen_title": screen_title,
        "description": description,
        "ui_state": ui_state,
        "feature_group": feature_group,
        "flow_step": flow_step,
        "flow_total": flow_total,
        "click_target_keywords": click_target_keywords or [],
        "annotation_text": annotation_text or "",
        "annotation_target_keywords": annotation_target_keywords or [],
        "width": 1440,
        "height": 1080,
        "sections": [{
            "section_name": "Main Content",
            "purpose": description,
            "components": components or [],
        }],
        "images": [],
    }
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
def parse_plan(raw: str) -> dict:
    cleaned = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
    start = cleaned.find('{')
    end   = cleaned.rfind('}')
    if start != -1 and end != -1:
        cleaned = cleaned[start:end + 1]
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        raise ValueError(f"Planner returned invalid JSON: {e}\n\nRaw:\n{raw[:800]}")

    pages = data.get("pages", [])
    for i, page in enumerate(pages):
        if "id" not in page:
            page["id"] = f"frame{i+1}"
        if "screen_title" not in page:
            page["screen_title"] = page.get("name", f"Frame {i+1}")
        if "feature_group" not in page:
            page["feature_group"] = page.get("name", f"Frame {i+1}").split("—")[0].strip()
        if "flow_step" not in page:
            page["flow_step"] = i + 1
        if "flow_total" not in page:
            page["flow_total"] = len(pages)
        if "click_target_keywords" not in page:
            page["click_target_keywords"] = []
        if "annotation_text" not in page:
            page["annotation_text"] = ""
        if "annotation_target_keywords" not in page:
            page["annotation_target_keywords"] = []
        if "width" not in page:
            page["width"] = 1440
        if "height" not in page:
            page["height"] = 1080
        if "images" not in page:
            page["images"] = []
        if "sections" not in page:
            page["sections"] = []

    return {
        "project_title": data.get("project_title", "Untitled Project"),
        "total_pages":   data.get("total_pages", len(pages)),
        "pages":         pages,
        "navigation_model": data.get("navigation_model", {}),
    }


def _parse_state_list(raw: str) -> list:
    cleaned = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
    start = cleaned.find('[')
    end   = cleaned.rfind(']')
    if start != -1 and end != -1:
        cleaned = cleaned[start:end + 1]
    try:
        result = json.loads(cleaned)
        return result if isinstance(result, list) else []
    except json.JSONDecodeError:
        log.warn("PLANNER", "State extraction JSON failed — falling back to generic flow planner")
        return []


def _build_plan_from_states(ui_states: list, user_prompt: str) -> dict:
    pages = []
    for i, state in enumerate(ui_states):
        pages.append({
            "id":            state.get("id", f"frame{i+1}"),
            "name":          state.get("name", f"Frame {i+1}"),
            "screen_title":  state.get("screen_title", state.get("name", f"Frame {i+1}")),
            "description":   state.get("description", ""),
            "ui_state":      state.get("ui_state", "default"),
            "feature_group": state.get("feature_group", ""),
            "flow_step":     state.get("flow_step", i + 1),
            "flow_total":    state.get("flow_total", len(ui_states)),
            "click_target_keywords": state.get("click_target_keywords", []),
            "annotation_text": state.get("annotation_text", ""),
            "annotation_target_keywords": state.get("annotation_target_keywords", []),
            "width":         1440,
            "height":        state.get("height", 1080),
            "sections": [{
                "section_name": "Main Content",
                "purpose":      state.get("description", ""),
                "components":   state.get("components", []),
            }],
            "images": [],
        })
    title = "CRM System" if "crm" in user_prompt.lower() else "Product Design"
    return {"project_title": title, "total_pages": len(pages), "pages": pages}

async def run_planner(user_prompt: str, content_context: dict = None) -> dict:
    log.info("PLANNER", f"Starting — prompt: {user_prompt[:80]!r}")

    has_content = bool(
        content_context and (
            content_context.get("features") or
            content_context.get("key_workflows") or
            content_context.get("pages_or_screens")
        )
    )

    if has_content:
        log.info("PLANNER", "STRUCTURED MODE — extracting UI states from document")
        context_str      = json.dumps(content_context, indent=2)
        extractor_prompt = STATE_EXTRACTOR_PROMPT.replace("{content_context}", context_str[:6000])

        ext_response = await generate_content_with_retry(
            client=client,
            model=planner_model,
            contents=extractor_prompt,
            config={"temperature": 0.2},
            log_tag="PLANNER",
            action="Extract structured UI states",
        )
        ui_states    = _parse_state_list(ext_response.text)

        if ui_states:
            log.info("PLANNER", f"Extracted {len(ui_states)} UI states")
            for s in ui_states[:20]:
                log.info("PLANNER", f"  → {s.get('name','?')}")

            synthesized = await _run_flow_synthesis(ui_states, content_context or {})
            if synthesized:
                log.info("PLANNER", f"Flow synthesis returned {len(synthesized)} state(s)")
                ui_states = synthesized
            else:
                log.warn("PLANNER", "Flow synthesis empty — using heuristic flow cleanup")

            cleaned_states = _cleanup_flow_states(ui_states)
            parsed = _build_plan_from_states(cleaned_states or ui_states, user_prompt)
            parsed["pages"] = _normalise_pages(parsed["pages"])
            parsed["pages"], parsed["navigation_model"] = _attach_project_structure(parsed["pages"])
            parsed["total_pages"] = len(parsed["pages"])
            log.success("PLANNER",
                f"Plan ready — {parsed['project_title']!r}  frames={parsed['total_pages']}"
            )
            return parsed
        else:
            log.warn("PLANNER", "State extraction empty — falling back to generic flow planner")

    # GENERIC FLOW MODE
    log.info("PLANNER", "FLOW MODE — generic flow plan from prompt")
    full_prompt = FREE_PLANNER_PROMPT.replace("{user_prompt}", user_prompt)

    response = await generate_content_with_retry(
        client=client,
        model=planner_model,
        contents=full_prompt,
        config={"temperature": 0.3},
        log_tag="PLANNER",
        action="Build generic flow plan",
    )
    raw_text  = response.text
    log.debug("PLANNER", f"Raw response: {len(raw_text)} chars")

    parsed = parse_plan(raw_text)
    parsed["pages"] = _normalise_pages(_cleanup_flow_states(parsed["pages"]) or parsed["pages"])
    parsed["pages"], parsed["navigation_model"] = _attach_project_structure(parsed["pages"])
    parsed["total_pages"] = len(parsed["pages"])
    log.success("PLANNER",
        f"Plan ready — project={parsed['project_title']!r}  pages={parsed['total_pages']}",
        extra={"total_pages": parsed["total_pages"]}
    )
    for p in parsed["pages"]:
        log.info("PLANNER",
            f"  → {p['name']}  ({p['width']}×{p['height']}px)  images={len(p.get('images',[]))}",
            extra={"page_id": p["id"]}
        )
    return parsed
